<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>

<?php
$larghezza_canvas = 1000;
$altezza_canvas = 800;
$spostamento_verticale = 120; // Spostamento di 50 pixel verso l'alto
$margin_top = (500 - $altezza_canvas / 2) - $spostamento_verticale;
$margin_left = (500 - $larghezza_canvas / 2);
?>

<style>
    body {
    margin: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
    background-color: #f0f0f0; /* Cambia il colore dello sfondo come preferisci */
}

canvas {
    border: 10px solid rgb(68, 68, 68);
    background-color: rgb(248, 248, 248);
    margin-top: <?php echo $margin_top; ?>px;
    margin-left: <?php echo $margin_left; ?>px;
}
</style>

</head>
<body onload="startGame()">

<?php
echo "<script>
var myGamePiece;
var cubo1 = [];
var cubo2 = [];
var cubo3 = [];
var cubo4 = [];
var myScore;
</script>";
?>

<?php
echo "<script>
function startGame() {
    myGamePiece = new component(15, 15, 'black', 10, 120, 'player');
    myScore = new component('30px', 'Consolas', 'black', 10, 40, 'text');
    myGameArea.start();
}
</script>";
?>

<script>
var myGameArea = {
    canvas: document.createElement("canvas"),
    start: function() {
        this.canvas.width = 1000;
        this.canvas.height = 800;
        this.frameNo = 0;
        this.context = this.canvas.getContext("2d");
        document.body.insertBefore(this.canvas, document.body.childNodes[0]);
        this.interval = setInterval(updateGameArea, 20);
        window.addEventListener('keydown', function (e) {
            myGameArea.keys = (myGameArea.keys || []);
            myGameArea.keys[e.keyCode] = (e.type == "keydown");
        })
        window.addEventListener('keyup', function (e) {
            myGameArea.keys[e.keyCode] = (e.type == "keydown");
        })
    },
    clear: function() {
        this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
}

function component(width, height, color, x, y, type) {
    this.type = type;
    this.width = width;
    this.height = height;
    this.speedX = 0;
    this.speedY = 0;
    this.x = x;
    this.y = y;
    this.update = function() {
        ctx = myGameArea.context;
        if (this.type === "player") {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.width, 0, 2 * Math.PI);
            ctx.fillStyle = color;
            ctx.fill();
        } else if (this.type === "text") {
            ctx.font = this.width + " " + this.height;
            ctx.fillStyle = color;
            ctx.fillText(this.text, this.x, this.y);
        } else {
            ctx.fillStyle = color;
            ctx.fillRect(this.x, this.y, this.width, this.height);
        }
    }

    this.newPos = function() {
        this.x += this.speedX;
        this.y += this.speedY;
    }

    this.crashWith = function(otherobj) {
        var myleft = this.x;
        var myright = this.x + this.width;
        var mytop = this.y;
        var mybottom = this.y + this.height;
        var otherleft = otherobj.x;
        var otherright = otherobj.x + otherobj.width;
        var othertop = otherobj.y;
        var otherbottom = otherobj.y + otherobj.height;
        var crash = true;
        if (mybottom < othertop || mytop > otherbottom || myright < otherleft || myleft > otherright) {
            crash = false;
        }
        return crash;
    }
}

function updateGameArea() {
    for (var i = 0; i < cubo1.length; i++) {
        if (myGamePiece.crashWith(cubo1[i])) {
            myGameArea.stop();
            return;
        }
    }

    for (var i = 0; i < cubo2.length; i++) {
        if (myGamePiece.crashWith(cubo2[i])) {
            myGameArea.stop();
            return;
        }
    }

    for (var i = 0; i < cubo3.length; i++) {
        if (myGamePiece.crashWith(cubo3[i])) {
            myGameArea.stop();
            return;
        }
    }

    for (var i = 0; i < cubo4.length; i++) {
        if (myGamePiece.crashWith(cubo4[i])) {
            myGameArea.stop();
            return;
        }
    }

    myGameArea.clear();
    myGameArea.frameNo++;
    myGamePiece.speedX = 0;
    myGamePiece.speedY = 0;

    if (myGameArea.keys && myGameArea.keys[37]) { myGamePiece.speedX = -10; }
    if (myGameArea.keys && myGameArea.keys[39]) { myGamePiece.speedX = 10; }
    if (myGameArea.keys && myGameArea.keys[38]) { myGamePiece.speedY = -10; }
    if (myGameArea.keys && myGameArea.keys[40]) { myGamePiece.speedY = 10; }

    if (myGamePiece.x >= 980 || myGamePiece.x <= 0) {
        myGamePiece.stop();
    }

    if (myGamePiece.y >= 780 || myGamePiece.y <= 0) {
        myGamePiece.stop();
    }

    if (myGameArea.frameNo === 1 || everyinterval(100)) {
        var num = Math.floor(Math.random() * 1000) + 10;
        var x = myGameArea.canvas.width;
        var y = myGameArea.canvas.height - num;
        cubo1.push(new component(30, 30, "brown", x, y));
    }

    if (myGameArea.frameNo > 100) {
        if (myGameArea.frameNo === 1 || everyinterval(100)) {
            num = Math.floor(Math.random() * 1000) + 10;
            x = myGameArea.canvas.width;
            y = myGameArea.canvas.height - num;
            cubo2.push(new component(30, 30, "green", x, y));
        }
    }

    if (myGameArea.frameNo > 130) {
        if (myGameArea.frameNo === 1 || everyinterval(80)) {
            num = Math.floor(Math.random() * 1000) + 10;
            x = myGameArea.canvas.width;
            y = myGameArea.canvas.height - num;
            cubo3.push(new component(30, 30, "red", x, y));
        }
    }

    if (myGameArea.frameNo > 200) {
        if (myGameArea.frameNo === 1 || everyinterval(82)) {
            num = Math.floor(Math.random() * 1000) + 10;
            x = myGameArea.canvas.width - num;
            y = myGameArea.canvas.height;
            cubo4.push(new component(30, 30, "blue", x, y));
        }
    }

    for (var i = 0; i < cubo1.length; i++) {
        cubo1[i].x += -2;
        cubo1[i].update();
    }

    for (var i = 0; i < cubo2.length; i++) {
        cubo2[i].x += -3;
        cubo2[i].update();
    }

    for (var i = 0; i < cubo3.length; i++) {
        cubo3[i].x += -6;
        cubo3[i].update();
    }

    for (var i = 0; i < cubo4.length; i++) {
        cubo4[i].y += -4;
        cubo4[i].update();
    }

    myScore.text = "PUNTEGGIO: " + myGameArea.frameNo;
    myScore.update();
    myGamePiece.newPos();
    myGamePiece.update();
}

function everyinterval(n) {
    return (myGameArea.frameNo / n) % 1 === 0;
}
</script>

</body>
</html>
